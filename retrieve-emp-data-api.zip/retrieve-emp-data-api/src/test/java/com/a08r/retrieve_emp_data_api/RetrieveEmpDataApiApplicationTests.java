package com.a08r.retrieve_emp_data_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RetrieveEmpDataApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
